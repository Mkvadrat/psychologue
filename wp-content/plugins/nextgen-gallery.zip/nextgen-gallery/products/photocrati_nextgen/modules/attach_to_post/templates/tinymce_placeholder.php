<script type="text/underscore-template" id="ngg-igw-placeholder">
    <div class="mceItem mceNonEditable nggPlaceholder"
         id="<%- ref %>"
         data-shortcode="<%- shortcode %>"
         data-mce-resize="false"
         data-mce-placeholder="1"
         contenteditable="false">
        <h3><%- nextgen_gallery %></h3>
        <div class="nggPlaceholderButton nggIgwEdit">
        	<%- edit %>	
        </div>
        <div class="nggPlaceholderButton nggIgwRemove">
        	<%- remove %>
        </div>
    </div>
</script>